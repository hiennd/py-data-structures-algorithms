**BlockChain**
**Datas tructure**
- LinkedList
**Time Complexity Analysis**
 1. Adding new block: O(1)
 2. Verifing chain: worst O(n)
 **Space Complexity Analysis**
 - Space: O(n)
 as a result of using linked list